#ifndef APPLICATION_H
#define APPLICATION_H

#include <QObject>

class Application : public QObject
{
    Q_OBJECT
public:
    Application();
};

#endif // APPLICATION_H
